# This file is a script, and is not meant to be imported into any other python file.
import pyautogui as pag
import time as t
import random as rand

def main ():
    # Enters Google Chrome
    pag.press('win')
    pag.write('Google Chrome')
    t.sleep(1)
    pag.press('enter')

    # Finds trendy songs on YouTube for Hot Potato
    t.sleep(1)
    pag.write('https://www.youtube.com')
    t.sleep(1)
    pag.press('enter')

    # Long wait to allow website to load
    t.sleep(5)
    pag.press('/')
    t.sleep(1)
    pag.write('Top 100 hits')
    t.sleep(1)

    for i in range (2):
        pag.press('enter')
        t.sleep(3)

    # Main logic of program; stops video at random times then starts again
    while True:
        t.sleep(rand.randint(5, 30))
        pag.press('k')
        t.sleep(7.5)
        pag.press('k')

# Prevents file from being run as a library
if __name__ == '__main__':
    main()